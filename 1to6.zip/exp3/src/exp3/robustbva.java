package exp3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class robustbva {
	@Test
	public void test01() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,1811),"Invalid Values");
		
	}
	@Test
	public void test1() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,1812),"17/6/1812");
		
	}
	@Test
	public void test2() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,1813),"17/6/1813");
	}
	@Test
	public void test3() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,1912),"17/6/1912");
	}
	@Test
	public void test4() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,2011),"17/6/2011");
	}
	@Test
	public void test5() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,2012),"17/6/2012");
	}
	@Test
	public void test05() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,2013),"Invalid Values");
		
	}
	@Test
	public void test06() {
		Next d = new Next();
		assertEquals(d.nextday(16,0,1912),"Invalid Values");
		
	}
	@Test
	public void test6() {
		Next d = new Next();
		assertEquals(d.nextday(16,1,1912),"17/1/1912");
	}
	@Test
	public void test7() {
		Next d = new Next();
		assertEquals(d.nextday(16,2,1912),"17/2/1912");
	}
	
	@Test
	public void test8() {
		Next d = new Next();
		assertEquals(d.nextday(16,11,1912),"17/11/1912");
	}
	@Test
	public void test9() {
		Next d = new Next();
		assertEquals(d.nextday(16,12,1912),"17/12/1912");
	}
	@Test
	public void test09() {
		Next d = new Next();
		assertEquals(d.nextday(16,13,1912),"Invalid Values");
		
	}
	@Test
	public void test010() {
		Next d = new Next();
		assertEquals(d.nextday(0,6,1912),"Invalid Values");
		
	}
	@Test
	public void test10() {
		Next d = new Next();
		assertEquals(d.nextday(1,6,1912),"2/6/1912");
	}
	@Test
	public void test11() {
		Next d = new Next();
		assertEquals(d.nextday(2,6,1912),"3/6/1912");
	}

	@Test
	public void test12() {
		Next d = new Next();
		assertEquals(d.nextday(30,6,1912),"1/7/1912");
	}
	@Test
	public void test13() {
		Next d = new Next();
		assertEquals(d.nextday(31,6,1912),"Invalid Values");
	}
	@Test
	public void test013() {
		Next d = new Next();
		assertEquals(d.nextday(32,6,1912),"Invalid Values");
		
	}

}
